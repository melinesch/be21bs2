### Prerequisites

This folder contains code examples of dhtmlxScheduler.

Some of them require a RESTful API on the backend.

This package includes a simple node.js app which is used for demonstration purposes only.
Please refer to the readme.txt at the package root for the instructions on how to run it.

## Tutorials

You can find detailed instructions on backend implementation here:

https://docs.dhtmlx.com/scheduler/howtostart_guides.html